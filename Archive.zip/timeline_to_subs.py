# timeline_to_subs.py
# Genera SRT y ASS desde timeline.json con estilos por orador y ajuste de línea.

import argparse, json, re
from pathlib import Path
from typing import Dict, Any, List

CONFIG_PATH = "config.json"

def read_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))

def load_cfg() -> Dict[str, Any]:
    return read_json(Path(CONFIG_PATH)) if Path(CONFIG_PATH).exists() else {}

def from_config_paths(cfg: Dict[str, Any]) -> tuple[Path, Path, Path]:
    slug = cfg.get("output_slug") or slugify(cfg.get("tema","podcast"))
    base = cfg.get("output_basename") or slug
    outdir = Path("outputs")/slug
    return outdir/f"{base}.timeline.json", outdir/f"{base}.srt", outdir/f"{base}.ass"

def slugify(texto: str) -> str:
    t = texto.lower()
    t = re.sub(r"[^a-z0-9áéíóúüñ\s-]", "", t)
    t = re.sub(r"\s+", "-", t)
    return re.sub(r"-+", "-", t).strip("-")

def fmt_srt_ts(sec: float) -> str:
    h=int(sec//3600); m=int((sec%3600)//60); s=sec%60
    return f"{h:02}:{m:02}:{s:06.3f}".replace(".",",")

def hex_to_ass_color(hexstr: str) -> str:
    # #RRGGBB -> &H00BBGGRR (BGR, alpha=00)
    hexstr = hexstr.strip().lstrip("#")
    if len(hexstr)!=6: return "&H00FFFFFF"
    rr=int(hexstr[0:2],16); gg=int(hexstr[2:4],16); bb=int(hexstr[4:6],16)
    return f"&H00{bb:02X}{gg:02X}{rr:02X}"

def wrap_text_for_srt(text: str, max_len: int = 52) -> str:
    # Envuelve en 2-3 líneas sin partir palabras, inserta \n
    words=text.split()
    lines=[]; cur=""
    for w in words:
        if len(cur)+len(w)+1>max_len:
            lines.append(cur.strip()); cur=w
        else:
            cur = (cur+" "+w).strip()
    if cur: lines.append(cur)
    # no más de 3 líneas: redistribuye si hiciera falta
    if len(lines)>3:
        merged=" ".join(lines)
        return wrap_text_for_srt(merged, max_len=max_len+10)
    return "\n".join(lines)

def build_from_timeline(timeline: Path, srt: Path, ass: Path, cfg: Dict[str, Any]) -> None:
    data=read_json(timeline); segs=data.get("segments",[])
    # Velocidad aproximada 160 wpm ~ 2.666 wps
    t=0.0
    srt_blocks=[]
    ass_events=[]
    # estilos
    font = cfg.get("subtitle_font", "Arial")
    fontsize = int(cfg.get("subtitle_fontsize", 60))
    margin_v = int(cfg.get("subtitle_margin_v", 40))
    margin_lr = int(cfg.get("subtitle_margin_lr", 140))
    outline = float(cfg.get("subtitle_outline", 2.0))
    shadow = int(cfg.get("subtitle_shadow", 1))

    use_colors = bool(cfg.get("use_speaker_colors", True))
    color_hector = hex_to_ass_color(cfg.get("color_hector", "#2EA8E6")) if use_colors else "&H00FFFFFF"
    color_aura   = hex_to_ass_color(cfg.get("color_aura",   "#FFD23F")) if use_colors else "&H00FFFFFF"
    color_base   = "&H00FFFFFF"

    # Header ASS
    ass_header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment, MarginL,MarginR,MarginV,Encoding
Style: Base,{font},{fontsize},{color_base},{color_base},&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,{outline},{shadow},2,{margin_lr},{margin_lr},{margin_v},1
Style: Hector,{font},{fontsize},{color_hector},{color_hector},&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,{outline},{shadow},2,{margin_lr},{margin_lr},{margin_v},1
Style: Aura,{font},{fontsize},{color_aura},{color_aura},&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,{outline},{shadow},2,{margin_lr},{margin_lr},{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    for idx, s in enumerate(segs, start=1):
        speaker = s.get("speaker","NARRATOR")
        text = s.get("text","").strip()
        words = max(1, len(re.findall(r"\w+", text)))
        dur = max(2.0, words/2.666)
        start, end = t, t+dur
        t = end + 0.12

        # SRT (envuelto)
        srt_text = wrap_text_for_srt(f"{text}", max_len=52)
        srt_blocks.append(f"{idx}\n{fmt_srt_ts(start)} --> {fmt_srt_ts(end)}\n{srt_text}\n")

        # ASS
        style = "Base"
        if speaker == "HECTOR": style = "Hector"
        elif speaker == "AURA": style = "Aura"
        # \N para permitir multilínea
        ass_text = srt_text.replace("\n", r"\N")
        ass_events.append(f"Dialogue: 0,{start:.2f},{end:.2f},{style},,0,0,0,,{ass_text}")

    srt.write_text("\n".join(srt_blocks), encoding="utf-8")
    ass.write_text(ass_header + "\n".join(ass_events), encoding="utf-8")

if __name__=="__main__":
    ap = argparse.ArgumentParser(description="Genera SRT/ASS desde timeline.json")
    ap.add_argument("--tema-from-config", action="store_true")
    ap.add_argument("--timeline", default=None)
    ap.add_argument("--srt", default=None)
    ap.add_argument("--ass", default=None)
    args = ap.parse_args()

    cfg = load_cfg()
    if args.tema_from_config:
        timeline, srt, ass = from_config_paths(cfg)
    else:
        if not all([args.timeline, args.srt, args.ass]):
            raise SystemExit("❌ Debes indicar --timeline, --srt y --ass si no usas --tema-from-config")
        timeline, srt, ass = Path(args.timeline), Path(args.srt), Path(args.ass)

    build_from_timeline(timeline, srt, ass, cfg)
    print(f"✅ Subtítulos generados: {srt} + {ass}")